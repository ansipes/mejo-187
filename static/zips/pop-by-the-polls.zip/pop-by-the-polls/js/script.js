/* Navbar */

// get the hamburger element

// get the menu element

// get the overlay element

// define toggle function

// execute toggle function from hamburger on click

// exuecute toggle function from overlay on click

/* Navbar */
